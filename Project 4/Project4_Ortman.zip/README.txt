Instead of redoing this project in Perl, I decided to do it in Python since I understand it better. 

To run, in your command prompt call 
python fasta_parse.py target_genes.seq 