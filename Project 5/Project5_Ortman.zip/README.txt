To run, in your command prompt call 
python primer_select.py primer3_output.txt left 

or
python primer_select.py primer3_output.txt right

or 
python primer_select.py primer3_output.txt product